// { "framework": "Vue" }

"use weex:vue";


/******/
(function(modules) { // webpackBootstrap
    /******/ // The module cache
    /******/
    var installedModules = {};

    /******/ // The require function
    /******/
    function __webpack_require__(moduleId) {

        /******/ // Check if module is in cache
        /******/
        if (installedModules[moduleId])
        /******/
            return installedModules[moduleId].exports;

        /******/ // Create a new module (and put it into the cache)
        /******/
        var module = installedModules[moduleId] = {
            /******/
            exports: {},
            /******/
            id: moduleId,
            /******/
            loaded: false
                /******/
        };

        /******/ // Execute the module function
        /******/
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

        /******/ // Flag the module as loaded
        /******/
        module.loaded = true;

        /******/ // Return the exports of the module
        /******/
        return module.exports;
        /******/
    }


    /******/ // expose the modules object (__webpack_modules__)
    /******/
    __webpack_require__.m = modules;

    /******/ // expose the module cache
    /******/
    __webpack_require__.c = installedModules;

    /******/ // __webpack_public_path__
    /******/
    __webpack_require__.p = "";

    /******/ // Load entry module and return exports
    /******/
    return __webpack_require__(0);
    /******/
})
/************************************************************************/
/******/
([
    /* 0 */
    /***/
    (function(module, exports, __webpack_require__) {

        'use strict';

        var _App = __webpack_require__(1);

        var _App2 = _interopRequireDefault(_App);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        _App2.default.el = '#root';
        new Vue(_App2.default);

        /***/
    }),
    /* 1 */
    /***/
    (function(module, exports, __webpack_require__) {

        var __vue_exports__, __vue_options__
        var __vue_styles__ = []

        /* styles */
        __vue_styles__.push(__webpack_require__(2))

        /* script */
        __vue_exports__ = __webpack_require__(3)

        /* template */
        var __vue_template__ = __webpack_require__(4)
        __vue_options__ = __vue_exports__ = __vue_exports__ || {}
        if (
            typeof __vue_exports__.default === "object" ||
            typeof __vue_exports__.default === "function"
        ) {
            if (Object.keys(__vue_exports__).some(function(key) {
                    return key !== "default" && key !== "__esModule"
                })) {
                console.error("named exports are not supported in *.vue files.")
            }
            __vue_options__ = __vue_exports__ = __vue_exports__.default
        }
        if (typeof __vue_options__ === "function") {
            __vue_options__ = __vue_options__.options
        }
        __vue_options__.__file = "/usr/src/app/raw/a0c6390cbbfe20d597545a8bd5ce173b/App.vue"
        __vue_options__.render = __vue_template__.render
        __vue_options__.staticRenderFns = __vue_template__.staticRenderFns
        __vue_options__._scopeId = "data-v-1c7312fc"
        __vue_options__.style = __vue_options__.style || {}
        __vue_styles__.forEach(function(module) {
            for (var name in module) {
                __vue_options__.style[name] = module[name]
            }
        })
        if (typeof __register_static_styles__ === "function") {
            __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
        }

        module.exports = __vue_exports__


        /***/
    }),
    /* 2 */
    /***/
    (function(module, exports) {

        module.exports = {
            "item-container": {
                "width": 750,
                "height": 276,
                "paddingTop": 24,
                "paddingLeft": 30,
                "paddingRight": 30,
                "paddingBottom": 24,
                "backgroundColor": "#ffffff",
                "flexDirection": "row"
            },
            "item-pic": {
                "width": 216,
                "height": 216
            },
            "item-info": {
                "width": 454,
                "height": 216,
                "marginLeft": 20,
                "flexDirection": "column",
                "justifyContent": "space-between"
            },
            "title": {
                "fontSize": 28,
                "fontWeight": "bold",
                "color": "#333333"
            },
            "shop": {
                "fontSize": 24,
                "color": "#999999",
                "marginTop": 10
            },
            "bottom": {
                "width": 454,
                "flexDirection": "row",
                "alignItems": "flex-end",
                "justifyContent": "space-between"
            },
            "buy-info": {
                "flexDirection": "row",
                "alignItems": "flex-end"
            },
            "price": {
                "color": "#f40000",
                "fontSize": 28,
                "fontWeight": "bold"
            },
            "sold": {
                "marginLeft": 10,
                "fontSize": 28,
                "color": "#999999"
            },
            "buy": {
                "width": 80,
                "height": 80,
                "color": "#ffffff",
                "fontSize": 40,
                "backgroundColor": "#f40000",
                "textAlign": "center",
                "paddingTop": 16,
                "borderRadius": 40
            }
        }

        /***/
    }),
    /* 3 */
    /***/
    (function(module, exports) {

        "use strict";

        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //

        module.exports = {
            props: {
                title: {
                    default: "COCOON/可可尼2017夏装新品甜美彩绘印花无袖修身连衣裙"
                },
                itemId: {
                    default: 545194660752
                },
                shop: {
                    default: "测试旗舰店"
                },
                pic: {
                    default: "https://img.alicdn.com/bao/uploaded/i1/468333872/TB2ZpPse8NkpuFjy0FaXXbRCVXa_!!468333872.jpg_b.jpg"
                },
                sold: {
                    default: "1050"
                },
                price: {
                    default: "102.0"
                }
            },
            created: function created() {
                a = 1;
                1 / b;
            },
            methods: {}
        };

        /***/
    }),
    /* 4 */
    /***/
    (function(module, exports) {

        module.exports = {
            render: function() {
                var _vm = this;
                var _h = _vm.$createElement;
                var _c = _vm._self._c || _h;
                return _c('div', {}, [_c('div', {
                    staticClass: ["item-container"],
                    on: {
                        "click": _vm.detailClick
                    }
                }, [_c('image', {
                    staticClass: ["item-pic"],
                    attrs: {
                        "src": _vm.pic
                    }
                }), _c('div', {
                    staticClass: ["item-info"]
                }, [_c('div', [_c('text', {
                    staticClass: ["title"]
                }, [_vm._v(_vm._s(_vm.title))]), _c('text', {
                    staticClass: ["shop"]
                }, [_vm._v(_vm._s(_vm.shop))])]), _c('div', {
                    staticClass: ["bottom"]
                }, [_c('div', {
                    staticClass: ["buy-info"]
                }, [_c('text', {
                    staticClass: ["price"]
                }, [_vm._v("￥" + _vm._s(_vm.price))]), _c('text', {
                    staticClass: ["sold"]
                }, [_vm._v("销量" + _vm._s(_vm.sold) + "笔")])]), _c('text', {
                    staticClass: ["buy"],
                    on: {
                        "click": _vm.buyClick
                    }
                }, [_vm._v("买")])])])])])
            },
            staticRenderFns: []
        }
        module.exports.render._withStripped = true

        /***/
    })
    /******/
]);