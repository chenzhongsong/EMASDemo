// { "framework": "Vue" }

"use weex:vue";


/******/
(function(modules) { // webpackBootstrap
    /******/ // The module cache
    /******/
    var installedModules = {};

    /******/ // The require function
    /******/
    function __webpack_require__(moduleId) {

        /******/ // Check if module is in cache
        /******/
        if (installedModules[moduleId])
        /******/
            return installedModules[moduleId].exports;

        /******/ // Create a new module (and put it into the cache)
        /******/
        var module = installedModules[moduleId] = {
            /******/
            exports: {},
            /******/
            id: moduleId,
            /******/
            loaded: false
                /******/
        };

        /******/ // Execute the module function
        /******/
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

        /******/ // Flag the module as loaded
        /******/
        module.loaded = true;

        /******/ // Return the exports of the module
        /******/
        return module.exports;
        /******/
    }


    /******/ // expose the modules object (__webpack_modules__)
    /******/
    __webpack_require__.m = modules;

    /******/ // expose the module cache
    /******/
    __webpack_require__.c = installedModules;

    /******/ // __webpack_public_path__
    /******/
    __webpack_require__.p = "";

    /******/ // Load entry module and return exports
    /******/
    return __webpack_require__(0);
    /******/
})
/************************************************************************/
/******/
([
    /* 0 */
    /***/
    (function(module, exports, __webpack_require__) {

        'use strict';

        var _App = __webpack_require__(1);

        var _App2 = _interopRequireDefault(_App);

        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }

        _App2.default.el = '#root';
        new Vue(_App2.default);

        /***/
    }),
    /* 1 */
    /***/
    (function(module, exports, __webpack_require__) {

        var __vue_exports__, __vue_options__
        var __vue_styles__ = []

        /* styles */
        __vue_styles__.push(__webpack_require__(2))

        /* script */
        __vue_exports__ = __webpack_require__(3)

        /* template */
        var __vue_template__ = __webpack_require__(4)
        __vue_options__ = __vue_exports__ = __vue_exports__ || {}
        if (
            typeof __vue_exports__.default === "object" ||
            typeof __vue_exports__.default === "function"
        ) {
            if (Object.keys(__vue_exports__).some(function(key) {
                    return key !== "default" && key !== "__esModule"
                })) {
                console.error("named exports are not supported in *.vue files.")
            }
            __vue_options__ = __vue_exports__ = __vue_exports__.default
        }
        if (typeof __vue_options__ === "function") {
            __vue_options__ = __vue_options__.options
        }
        __vue_options__.__file = "/usr/src/app/raw/146fab0752fb0f156dce7b394a754aab/App.vue"
        __vue_options__.render = __vue_template__.render
        __vue_options__.staticRenderFns = __vue_template__.staticRenderFns
        __vue_options__._scopeId = "data-v-1a9488a6"
        __vue_options__.style = __vue_options__.style || {}
        __vue_styles__.forEach(function(module) {
            for (var name in module) {
                __vue_options__.style[name] = module[name]
            }
        })
        if (typeof __register_static_styles__ === "function") {
            __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
        }

        module.exports = __vue_exports__


        /***/
    }),
    /* 2 */
    /***/
    (function(module, exports) {

        module.exports = {
            "list": {
                "width": "750",
                "backgroundColor": "#EFEFEF"
            },
            "row": {
                "flexDirection": "row"
            },
            "tab-cell": {
                "backgroundColor": "#f51438"
            },
            "tab": {
                "height": "120",
                "width": "150",
                "justifyContent": "center",
                "alignItems": "center"
            },
            "tab-icon": {
                "width": "45",
                "height": "45"
            },
            "tab-title": {
                "fontSize": "28",
                "color": "#FFFFFF",
                "marginTop": "10"
            },
            "banner-image": {
                "width": "750",
                "height": "235"
            },
            "app-cell": {
                "backgroundColor": "#FFFFFF"
            },
            "app-box": {
                "width": "180",
                "paddingTop": "15",
                "paddingBottom": "15",
                "paddingLeft": "15",
                "paddingRight": "15"
            },
            "app-title": {
                "width": "180",
                "fontSize": "30",
                "textAlign": "center",
                "paddingTop": "15",
                "color": "#999999"
            },
            "app-icon": {
                "width": "140",
                "height": "140",
                "marginLeft": "20"
            },
            "card": {
                "width": "710",
                "marginTop": "20",
                "marginRight": "20",
                "marginBottom": "20",
                "marginLeft": "20",
                "backgroundColor": "#FFFFFF",
                "borderRadius": "15"
            },
            "card-banner": {
                "width": "222",
                "height": "60"
            },
            "card-side": {
                "paddingTop": "20",
                "paddingRight": "20",
                "paddingBottom": "20",
                "paddingLeft": "20"
            },
            "card-poster": {
                "width": "230",
                "height": "230",
                "marginRight": "20"
            },
            "card-title": {
                "fontSize": "26",
                "color": "#666666",
                "marginTop": "10",
                "paddingBottom": "6"
            },
            "card-line": {
                "alignItems": "center",
                "paddingTop": "5",
                "paddingBottom": "5"
            },
            "card-icon": {
                "width": "36",
                "height": "36",
                "marginRight": "8"
            },
            "card-subtitle": {
                "fontSize": "28",
                "color": "#07152a"
            },
            "card-progress": {
                "flexDirection": "row",
                "alignItems": "center",
                "width": "230",
                "height": "30",
                "backgroundColor": "#FEC1C1",
                "borderRadius": "20",
                "marginTop": "10",
                "marginBottom": "10"
            },
            "card-progress-inner": {
                "position": "absolute",
                "height": "30",
                "left": 0,
                "borderRadius": "20",
                "backgroundColor": "#ff3c32"
            },
            "card-got": {
                "position": "absolute",
                "left": "8",
                "lineHeight": "30",
                "color": "#FFFFFF",
                "fontSize": "22"
            },
            "card-remain": {
                "position": "absolute",
                "right": "8",
                "lineHeight": "30",
                "color": "#FFFFFF",
                "fontSize": "22"
            },
            "card-info": {
                "width": "400",
                "flexDirection": "row",
                "alignItems": "flex-end"
            },
            "card-price": {
                "fontSize": "52",
                "color": "#ff3c32",
                "marginBottom": "-10",
                "marginTop": "10",
                "marginRight": "8"
            },
            "card-sale-price": {
                "fontSize": "28",
                "color": "#999999",
                "textDecoration": "line-through"
            },
            "card-btn": {
                "position": "absolute",
                "right": 0,
                "bottom": 0,
                "backgroundColor": "#ff5d62",
                "borderRadius": "8",
                "width": "125",
                "height": "52",
                "justifyContent": "center"
            },
            "card-btn-text": {
                "color": "#FFFFFF",
                "fontSize": "32",
                "textAlign": "center"
            },
            "floor": {
                "marginBottom": "15",
                "backgroundColor": "#FFFFFF"
            },
            "floor-title": {
                "fontSize": "40",
                "textAlign": "center",
                "paddingTop": "35",
                "paddingBottom": "25"
            },
            "floor-desc": {
                "lines": 2,
                "color": "#999999",
                "fontSize": "30",
                "paddingLeft": "30",
                "paddingRight": "30"
            },
            "floor-image-box": {
                "flexDirection": "row",
                "justifyContent": "space-between",
                "marginTop": "20"
            },
            "floor-image": {
                "width": "245",
                "height": "245"
            },
            "floor-comment": {
                "color": "#52bfe6",
                "fontSize": "32",
                "textAlign": "right",
                "paddingRight": "50",
                "marginTop": "25",
                "marginBottom": "20"
            }
        }

        /***/
    }),
    /* 3 */
    /***/
    (function(module, exports) {

        'use strict';

        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //

        var dataset = {
            apps: [{
                type: 'apps',
                apps: [{
                    title: '鐑棬鎼厤',
                    icon: 'https://gw.alicdn.com/tfs/TB1wKS.h8fH8KJjy1XbXXbLdXXa-140-140.png_150x10000.jpg'
                }, {
                    title: '缃戠孩澶ц。',
                    icon: 'https://gw.alicdn.com/tfs/TB1oM1qaMvD8KJjy0FlXXagBFXa-140-140.png_150x10000.jpg'
                }, {
                    title: '鍥涗欢濂�',
                    icon: 'https://gw.alicdn.com/tfs/TB1Oiz0b22H8KJjy0FcXXaDlFXa-140-140.png_150x10000.jpg'
                }, {
                    title: '浜烘皵褰╁',
                    icon: 'https://gw.alicdn.com/tfs/TB1LhJzQFXXXXabXXXXXXXXXXXX-140-140.png_150x10000.jpg'
                }]
            }, {
                type: 'apps',
                apps: [{
                    title: '绾汉鏂板搧',
                    icon: 'https://gw.alicdn.com/tfs/TB1L5upaH_I8KJjy1XaXXbsxpXa-140-140.png_150x10000.jpg'
                }, {
                    title: '缃戠孩鎷栭瀷',
                    icon: 'https://gw.alicdn.com/tfs/TB1w.ocb3DD8KJjy0FdXXcjvXXa-140-140.png_150x10000.jpg'
                }, {
                    title: '鑵旇皟鎺屾煖',
                    icon: 'https://img.alicdn.com/tfs/TB1sWLoRVXXXXbdXXXXXXXXXXXX-140-140.png'
                }, {
                    title: '鏃跺皻鏂板搧',
                    icon: 'https://gw.alicdn.com/tfs/TB10.R_SpXXXXbtXXXXXXXXXXXX-140-140.png'
                }]
            }, {
                type: 'apps',
                apps: [{
                    title: '娼祦绌挎惌',
                    icon: 'https://img.alicdn.com/tfs/TB1fRVASpXXXXXdXXXXXXXXXXXX-140-140.png'
                }, {
                    title: '鏆栧績濂界墿',
                    icon: 'https://img.alicdn.com/tfs/TB1_TkdPVXXXXcJXXXXXXXXXXXX-140-140.png'
                }, {
                    title: '鏄庢槦闈㈣啘',
                    icon: 'https://img.alicdn.com/tps/TB1goZhPXXXXXXfXpXXXXXXXXXX-118-118.png_170x120Q50s50.jpg'
                }, {
                    title: '褰╁棣欐皼',
                    icon: 'https://img.alicdn.com/tps/TB1zUTQPXXXXXaZaXXXXXXXXXXX-118-118.png_170x120Q50s50.jpg'
                }]
            }],
            tab: [{
                type: 'tab',
                tabs: [{
                    title: '棣栭〉',
                    icon: 'https://gw.alicdn.com/tfs/TB19YESOVXXXXaNaXXXXXXXXXXX-45-45.png'
                }, {
                    title: '鑰嶅竻',
                    icon: 'https://gw.alicdn.com/tfs/TB1I2E9OVXXXXbFXVXXXXXXXXXX-45-45.png'
                }, {
                    title: '鏃呰',
                    icon: 'https://gw.alicdn.com/tfs/TB1gUhyPXXXXXX5XXXXXXXXXXXX-45-45.png'
                }, {
                    title: '娼帺',
                    icon: 'https://img.alicdn.com/tfs/TB1D4RzQFXXXXcoXpXXXXXXXXXX-45-45.png'
                }, {
                    title: '绌挎惌',
                    icon: 'https://gw.alicdn.com/tfs/TB1N1.6OVXXXXXqaXXXXXXXXXXX-45-45.png'
                }]
            }],
            banner: [{
                type: 'banner',
                src: 'https://img.alicdn.com/imgextra/i4/184/TB2LPjVhMLD8KJjSszeXXaGRpXa_!!184-0-luban.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://aecpm.alicdn.com/simba/img/TB1CWf9KpXXXXbuXpXXSutbFXXX.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://aecpm.alicdn.com/simba/img/TB14ab1KpXXXXclXFXXSutbFXXX.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://img.alicdn.com/imgextra/i4/61/TB24IbTh3fH8KJjy1zcXXcTzpXa_!!61-0-yamato.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/i2/145/TB24D30cMjN8KJjSZFkXXaboXXa_!!145-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/i3/161/TB2syUXcJLO8KJjSZPcXXaV0FXa_!!161-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/i4/167/TB2wrL8h26H8KJjSspmXXb2WXXa_!!167-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/i2/25/TB2GgAmhS_I8KJjy0FoXXaFnVXa_!!25-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/TB2uQAFhb_I8KJjy1XaXXbsxpXa_!!89-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://img.alicdn.com/simba/img/TB19heYdwn.PuJjSZFkSuw_lpXa.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://aecpm.alicdn.com/simba/img/TB14ab1KpXXXXclXFXXSutbFXXX.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://img.alicdn.com/imgextra/i1/174/TB2xzb0eOqAXuNjy1XdXXaYcVXa_!!174-0-luban.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/TB27XSvg6nD8KJjSspbXXbbEXXa_!!12-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/TB2cF.xfTnI8KJjSszbXXb4KFXa_!!112-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/TB2ZweVg9_I8KJjy0FoXXaFnVXa_!!158-0-lubanu.jpg_q50.jpg'
            }, {
                type: 'banner',
                src: 'https://gw.alicdn.com/imgextra/TB2O_AKctHO8KJjSZFtXXchfXXa_!!53-0-lubanu.jpg_q50.jpg'
            }],
            floor: [{
                type: 'floor',
                title: '灏遍€犱笓灞炴劅锛岀粰瀛╁瓙瀵讳釜搴ф濂界帺浼�',
                desc: '鐘硅寰楀効鏃剁殑椋庣瓭甯︾潃鏂戞枔鐨勮壊褰╁湪澶╃┖椋樿繃锛涢偅灏忔渤閲岃翰杩疯棌鐨勯奔铏撅紝杩樺緟鐫€灏忎紮浼翠滑涓€璧峰幓鎹曟崏锛屽浠婄殑瀛╃娌℃湁浜嗚繖浜涚畝鍗曚笖绾补鐨勫ū涔愰」鐩紝鐢熸椿鍦ㄩ珮妤煎煄甯備腑鐨勪粬浠紝璇ュ綋鎬庢牱搴﹁繃鑷繁鐨勭骞存墠鏄編濂界殑锛�',
                pictures: ['https://gw.alicdn.com/tfscom/i3/48292642/TB29OtIakz_F1JjSZFkXXcCaXXa_!!48292642.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i4/706778912/TB2hvwSXBvBIuJjy1zeXXbGBpXa_!!706778912-0-beehive-scenes.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i3/706778912/TB2wX.fcxz9F1JjSZFsXXaCGVXa_!!706778912-0-beehive-scenes.jpg_250x250q90s200.jpg'],
                count: 237
            }, {
                type: 'floor',
                title: '鐫¤绌夸笉瀵癸紝鑴卞厜涔熶笉濯氾紒',
                desc: '鈥淚hatemynightgown锛堟垜璁ㄥ帉鎴戠殑鐫¤锛�.鈥濈粡鍏哥數褰便€婄綏椹亣鏃ャ€嬩腑锛岃但鏈グ婕旂殑瀹夊Ξ鍏富韬哄湪姊﹀够鐨勫寤峰ぇ搴婁笂锛屾姳鎬ㄥス韬笂閭ｅ崕涓界殑澶х潯琚嶈噧鑲夸笉渚匡紝涓哄叕涓荤殑娴极閫冮€稿煁涓嬩紡绗斻€傛兂璞′竴涓嬶紝鐢锋湅鍙嬪垰鍒�',
                pictures: ['https://gw.alicdn.com/imgextra/i3/3044653839/TB2a_nAXgsSMeJjSspdXXXZ4pXa_!!3044653839-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i1/3044653839/TB2qrPCXiERMeJjSspiXXbZLFXa_!!3044653839-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i1/3044653839/TB2ySjuXgsSMeJjSspeXXa77VXa_!!3044653839-0-beehive-scenes.jpg_250x250q90s200.jpg'],
                count: 876
            }, {
                type: 'floor',
                title: '涓婂ぉ鍏ユ捣锛熻繍鍔ㄧ浉鏈哄府浣犳悶瀹�',
                desc: '鐜板浠婄浉鏈哄ソ鍍忔垚涓轰簡鎴戜滑姣忎釜浜哄繀涓嶅彲灏戠殑瑁呭锛屼笉绠℃槸涓撲笟鐨勭浉鏈鸿繕鏄垜浠彲鎷嶇収鐨勬墜鏈猴紝鎴戜滑浣跨敤鍒板畠鐨勯鐜囦篃瓒婃潵瓒婇珮銆備负浜嗚拷姹傛洿濂界殑鎷嶆憚璐ㄩ噺锛屼汉浠技涔庝篃鎰挎剰鑺辨洿澶氱殑閽卞幓璐拱濂界殑鎷嶆憚瑁呭',
                pictures: ['https://gw.alicdn.com/tfscom/i3/462856946/TB2VzQswB4lpuFjy1zjXXcAKpXa_!!462856946.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/tfscom/i2/2811920170/TB2rCqHpVXXXXcZXpXXXXXXXXXX_!!2811920170.png_250x250.jpg', 'https://gw.alicdn.com/imgextra/i4/836552381/TB2c1q3aZSfF1JjSsplXXbrKFXa_!!836552381-0-beehive-scenes.jpg_250x250q90s200.jpg'],
                count: 59
            }, {
                type: 'floor',
                title: '鍏充簬鍩规牴鐨勯偅浜涗簨锛屾暀浣犲悆寰楅棬娓�',
                desc: '鍩规牴涓€鐩磋璁や负鏄棭椁愮殑澶寸洏锛屾棭涓婄儰涓ょ墖闈㈠寘锛屽钩搴曢攨鐓庝竴鐗囧煿鏍广€佷竴涓浮铔嬶紝鍜岀敓鑿滀竴璧峰す鍦ㄩ潰鍖呬腑锛屾湁鑽ゆ湁绱狅紝灏辨槸涓€椤夸赴瀵岀編鍛崇殑瑗垮紡鏃╅銆傚煿鏍圭殑鑻辨枃鍚嶆槸鈥淏acon鈥濓紝鍘熸剰鏄儫鐔忕殑鐚倠鏉¤倝锛屾垨鐑熺啅鑳岃剨鑲�',
                pictures: ['https://gw.alicdn.com/imgextra/i2/603964020/TB24zFbarwTMeJjSszfXXXbtFXa_!!603964020-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i2/603964020/TB2txtdarsTMeJjy1zcXXXAgXXa_!!603964020-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/tfscom/i3/1635378022/TB2plKDbFXXXXaTXpXXXXXXXXXX-1635378022.jpg_250x250q90s200.jpg'],
                count: 3576
            }, {
                type: 'floor',
                title: '杞诲ア椋庢潵琚紝鐨壓搴婃墦閫犲吀闆呭眳瀹�',
                desc: '瀵逛簬杩芥眰鐢熸椿楂樺搧璐ㄦ劅鐨勫皬浼欎即鏉ヨ锛岀毊鑹哄鍏锋槸灞曠幇鍏堕珮鏍艰皟鐨勯€斿緞涔嬩竴銆傛兂瑕佽惀閫犲嚭濂㈠崕璐ㄦ劅鐨勫崸瀹ょ幆澧冿紝澶ф皵搴勯噸鐨勭毊搴婂綋鐒舵槸涓嶉敊鐨勯€夋嫨銆傜壒鍒槸绠€娆ч鎴栨槸缇庡紡鍙ゅ吀椋庢牸鐨勫灞呯幆澧冿紝濡傛灉閰嶄互鐨壓搴婄畝鐩村氨鏄偣鐫涗箣绗�',
                pictures: ['https://gw.alicdn.com/imgextra/i2/787557947/TB2erNKawoQMeJjy0FoXXcShVXa_!!787557947-0-beehive-scenes.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i1/787557947/TB2KANyaBUSMeJjy1zkXXaWmpXa_!!787557947-0-beehive-scenes.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i3/787557947/TB2lwdGayERMeJjy0FcXXc7opXa_!!787557947-0-beehive-scenes.jpg_250x250q90s200.jpg'],
                count: 36
            }, {
                type: 'floor',
                title: '鎻愰珮鍝佽川鐢熸椿锛屼粠鐢ㄥソ姘村紑濮�',
                desc: '鎴戜滑鐢熸椿涓瘡澶╅兘瑕佸枬姘淬€佺敤姘达紝鍙槸浣犵湡鐨勫枬鍒般€佺敤鍒板ソ姘翠簡涔堬紵涓轰簡寰楀埌鏇撮珮鍝佽川鐨勭敓娲伙紝鎴戜滑闇€瑕佹洿澶氱殑濂戒笢瑗胯鎴戜滑鐨勭敓娲绘洿鏈夋。娆★紝閭ｄ笉濡傚氨浠庢敼鍙樹綘姣忓ぉ閮借浜插瘑鎺ヨЕ鐨勬按寮€濮嬪惂',
                pictures: ['https://gw.alicdn.com/imgextra/i2/1904229646/TB2dRg4dgoQMeJjy0FpXXcTxpXa_!!1904229646-2-daren.png_250x250.jpg', 'https://gw.alicdn.com/imgextra/i1/1904229646/TB2JtOjfOAKL1JjSZFoXXagCFXa_!!1904229646-2-daren.png_250x250.jpg', 'https://gw.alicdn.com/imgextra/i1/1904229646/TB2BSXjdwsSMeJjSspeXXa77VXa_!!1904229646-2-daren.png_250x250.jpg'],
                count: 74
            }, {
                type: 'floor',
                title: '閰掗鍒颁簡鎰忓ぇ鍒╋紝鏀朵笉浣忕殑绾㈤厭蹇�',
                desc: '鎰忓ぇ鍒╂槸涓€涓泦鍙ゅ吀涓庤壓鏈簬涓€韬殑鍥藉害锛岃繖閲屾槸鑹烘湳鐨勫彂婧愬湴涔嬩竴锛屼篃鏄娲叉渶鏃╃妞嶈憽钀勭殑鍥藉涔嬩竴銆傛剰澶у埄鐨勯吙閰掑巻鍙茶秴杩�4000骞达紝鏈湴钁¤悇鍝佺杩囧崈涓嶆锛屽彜甯岃厞浜虹О鍏朵负鈥滆憽钀勯厭涔嬪浗鈥�',
                pictures: ['https://gw.alicdn.com/imgextra/i1/2872639756/TB21lwtXjihSKJjy0FiXXcuiFXa_!!2872639756-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i1/2872639756/TB2zgRJdwMPMeJjy1XdXXasrXXa_!!2872639756-0-daren.jpg_250x250q90s200.jpg', 'https://gw.alicdn.com/imgextra/i2/2872639756/TB2Ki0NdBUSMeJjSspfXXX0VFXa_!!2872639756-0-daren.jpg_250x250q90s200.jpg'],
                count: 182
            }],
            card: [{
                type: 'card',
                poster: 'http://gw.alicdn.com/tps/i4/1611893164/TB2t4mtXJqUQKJjSZFIXXcOkFXa_!!0-juitemmedia.jpg_320x320q80s150.jpg',
                title: '婢虫床鐗涙帓10浠借閫佸垁鍙夐叡鏂欓粍娌�',
                subtitle1: '閫佸钩搴曢攨鍓�3000浠�78',
                subtitle2: '绉佸帹缁忓吀 闀囧簵濂楅',
                got: 173,
                progress: 35,
                price: {
                    real: 108,
                    sale: 240.00
                }
            }, {
                type: 'card',
                poster: 'http://gw.alicdn.com/tps/i2/2838892713/TB2ma39aqmgSKJjSsphXXcy1VXa_!!0-juitemmedia.jpg_320x320q80s150.jpg',
                title: 'HUAWEI P10',
                subtitle1: '涔拌禒濂界ぜ6鏈熷厤鎭�',
                subtitle2: '6鏈熷厤鎭�',
                got: 996,
                progress: 89,
                price: {
                    real: 3488,
                    sale: 3488.00
                }
            }, {
                type: 'card',
                poster: 'http://gw.alicdn.com/tps/i3/902257410/TB2pzypfU3IL1JjSZFMXXajrFXa_!!0-juitemmedia.jpg_320x320q80s150.jpg',
                title: '娴峰畞鐪熺毊鐨。鐢风坏缇婄毊澶瑰厠澶栧',
                subtitle1: '搴楀唴棰嗗埜涓嬪崟438',
                subtitle2: '闄愰€�500鍙岀毊鎵嬪',
                got: 296,
                progress: 16,
                price: {
                    real: 538,
                    sale: 3080.00
                }
            }, {
                type: 'card',
                poster: 'https://gw.alicdn.com/tps/i4/0/TB2Mx3Jg4TI8KJjSspiXXbM4FXa_!!0-juitemmedia.jpg_320x320q80s150.jpg',
                title: '鐜涗附榛涗匠鍏冩皵椋庡姩涓夎壊鑵孩姝ｅ搧',
                subtitle1: '婊�108棰嗗埜绔嬪噺10鍏�',
                subtitle2: '瀹涜嫢澶╃敓绮夌孩濂芥皵鑹�',
                got: 1457,
                progress: 61,
                price: {
                    real: 49,
                    sale: 69.80
                }
            }, {
                type: 'card',
                poster: 'https://gw.alicdn.com/tps/i2/0/TB2i25DgN6I8KJjSszfXXaZVXXa_!!0-juitemmedia.jpg_320x320q80s150.jpg',
                title: '鐜嬪皬浜岄珮灞辫剱姗欙紝閰哥敎濡傚垵鎭�',
                subtitle1: '鍓�3鍒嗛挓鍗婁环',
                subtitle2: 'VC浠撳簱锛岄吀鐢滃鍒濇亱',
                got: 598,
                progress: 42,
                price: {
                    real: 29.8,
                    sale: 56.10
                }
            }]

            // generate list data
        };

        function createListData(order) {
            var array = [];
            var list = order.split(/[\s,]+/);
            for (var i = 0; i < list.length; ++i) {
                var candidates = dataset[list[i]];
                if (candidates) {
                    var idx = Math.floor(Math.random() * candidates.length);
                    array.push(candidates[idx]);
                }
            }
            return array;
        }

        exports.default = {
            data: function data() {
                var blockList = 'tab,banner,apps,apps,banner,card,floor,floor' + ',tab,apps,apps,banner,card,card,banner,floor,floor,floor' + ',tab,banner,card,apps,banner,card,floor,floor,floor,floor,floor' + ',tab,apps,banner,card,banner,floor,floor,floor' + ',tab,apps,apps,card,floor,card,banner,floor,floor' + ',tab,banner,card,apps,banner,card,floor,floor,floor,floor' + ',tab,apps,banner,card,card,apps,floor,floor,floor';
                var order = blockList + ',' + blockList + ',' + blockList + ',' + blockList;
                return {
                    longList: createListData(order)
                };
            }
        };

        /***/
    }),
    /* 4 */
    /***/
    (function(module, exports) {

        module.exports = {
            render: function() {
                var _vm = this;
                var _h = _vm.$createElement;
                var _c = _vm._self._c || _h;
                return _c('list', {
                    staticClass: ["list"]
                }, [_vm._l((_vm.longList), function(item, index) {
                    return [(item.type === 'tab') ? _c('cell', {
                        key: index,
                        staticClass: ["tab-cell", "row"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, _vm._l((item.tabs), function(tab, t) {
                        return _c('div', {
                            key: t,
                            staticClass: ["tab"]
                        }, [_c('image', {
                            staticClass: ["tab-icon"],
                            attrs: {
                                "src": tab.icon
                            }
                        }), _c('text', {
                            staticClass: ["tab-title"]
                        }, [_vm._v(_vm._s(tab.title))])])
                    })) : _vm._e(), (item.type === 'banner') ? _c('cell', {
                        key: index,
                        staticClass: ["banner-cell"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, [_c('image', {
                        staticClass: ["banner-image"],
                        attrs: {
                            "src": item.src
                        }
                    })]) : _vm._e(), (item.type === 'apps') ? _c('cell', {
                        key: index,
                        staticClass: ["app-cell", "row"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, _vm._l((item.apps), function(app, a) {
                        return _c('div', {
                            key: a,
                            staticClass: ["app-box"]
                        }, [_c('image', {
                            staticClass: ["app-icon"],
                            attrs: {
                                "src": app.icon
                            }
                        }), _c('text', {
                            staticClass: ["app-title"]
                        }, [_vm._v(_vm._s(app.title))])])
                    })) : _vm._e(), (item.type === 'card') ? _c('cell', {
                        key: index,
                        staticClass: ["card-cell"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, [_c('div', {
                        staticClass: ["card"]
                    }, [_vm._m(0, true, false), _c('div', {
                        staticClass: ["row"],
                        staticStyle: {
                            paddingBottom: "18px"
                        }
                    }, [_c('div', {
                        staticClass: ["card-side"]
                    }, [_c('image', {
                        staticClass: ["card-poster"],
                        attrs: {
                            "src": item.poster
                        }
                    })]), _c('div', {
                        staticClass: ["card-message"]
                    }, [_c('text', {
                        staticClass: ["card-title"]
                    }, [_vm._v(_vm._s(item.title))]), _c('div', {
                        staticClass: ["card-line", "row"]
                    }, [_c('image', {
                        staticClass: ["card-icon"],
                        attrs: {
                            "src": "//ossgw.alicdn.com/img/upload/0a4946e164acd1f81e97ddbc048afcc5/Group13-69-69.png@22w_22h_80Q.png"
                        }
                    }), _c('text', {
                        staticClass: ["card-subtitle"]
                    }, [_vm._v(_vm._s(item.subtitle1))])]), _c('div', {
                        staticClass: ["card-line", "row"]
                    }, [_c('image', {
                        staticClass: ["card-icon"],
                        attrs: {
                            "src": "//ossgw.alicdn.com/img/upload/0a4946e164acd1f81e97ddbc048afcc5/Group13-69-69.png@22w_22h_80Q.png"
                        }
                    }), _c('text', {
                        staticClass: ["card-subtitle"]
                    }, [_vm._v(_vm._s(item.subtitle2))])]), _c('div', {
                        staticClass: ["card-progress", "row"]
                    }, [_c('div', {
                        staticClass: ["card-progress-inner"],
                        style: {
                            width: item.progress * 230 / 100
                        }
                    }), _c('text', {
                        staticClass: ["card-got"]
                    }, [_vm._v("宸叉姠 " + _vm._s(item.got) + " 浠�")]), _c('text', {
                        staticClass: ["card-remain"]
                    }, [_vm._v(_vm._s(item.progress) + " %")])]), _c('div', {
                        staticClass: ["card-info", "row"]
                    }, [_c('text', {
                        staticClass: ["card-price"]
                    }, [_vm._v("楼 " + _vm._s(item.price.real))]), _c('text', {
                        staticClass: ["card-sale-price"]
                    }, [_vm._v("楼 " + _vm._s(item.price.sale))]), _vm._m(1, true, false)])])])])]) : _vm._e(), (item.type === 'floor') ? _c('cell', {
                        key: index,
                        staticClass: ["floor-cell"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, [_c('div', {
                        staticClass: ["floor"]
                    }, [_c('text', {
                        staticClass: ["floor-title"]
                    }, [_vm._v(_vm._s(item.title))]), _c('text', {
                        staticClass: ["floor-desc"],
                        attrs: {
                            "lines": "2"
                        }
                    }, [_vm._v(_vm._s(item.desc))]), _c('div', {
                        staticClass: ["floor-image-box", "row"]
                    }, _vm._l((item.pictures), function(source, x) {
                        return _c('image', {
                            key: x,
                            staticClass: ["floor-image"],
                            attrs: {
                                "src": source
                            }
                        })
                    })), (item.count) ? _c('text', {
                        staticClass: ["floor-comment"]
                    }, [_vm._v(_vm._s(item.count) + " 浜鸿濂�")]) : _vm._e()])]) : _vm._e(), (item.type === 'chat') ? _c('cell', {
                        key: index,
                        staticClass: ["chat-cell"],
                        appendAsTree: true,
                        attrs: {
                            "append": "tree"
                        }
                    }, [_c('text', {
                        staticClass: ["banner-title"]
                    }, [_vm._v("chat")])]) : _vm._e()]
                })], 2)
            },
            staticRenderFns: [function() {
                var _vm = this;
                var _h = _vm.$createElement;
                var _c = _vm._self._c || _h;
                return _c('div', {
                    staticStyle: {
                        height: "60px",
                        paddingLeft: "30"
                    }
                }, [_c('image', {
                    staticClass: ["card-banner"],
                    attrs: {
                        "src": "//img.alicdn.com/tfs/TB1moeURFXXXXasXXXXXXXXXXXX-390-105.png"
                    }
                })])
            }, function() {
                var _vm = this;
                var _h = _vm.$createElement;
                var _c = _vm._self._c || _h;
                return _c('div', {
                    staticClass: ["card-btn"]
                }, [_c('text', {
                    staticClass: ["card-btn-text"]
                }, [_vm._v("椹笂鎶�")])])
            }]
        }
        module.exports.render._withStripped = true

        /***/
    })
    /******/
]);